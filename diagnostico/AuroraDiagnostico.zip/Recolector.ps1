﻿# Aurora Diagnóstico · Recolector común
# Compatible con Windows PowerShell 5.1. Se carga con punto: . .\Recolector.ps1
# Expone: Get-AuroraDiagnostico, ConvertTo-AuroraHtml, Export-AuroraInforme, Get-AuroraEstadoRapido

Set-StrictMode -Off
$ErrorActionPreference = 'SilentlyContinue'
$script:AuroraVersion = '1.0.0'
$script:RecolectorDir = Split-Path -Parent $MyInvocation.MyCommand.Path

function Test-EsAdmin {
  $id = [Security.Principal.WindowsIdentity]::GetCurrent()
  $p = New-Object Security.Principal.WindowsPrincipal($id)
  return $p.IsInRole([Security.Principal.SecurityIdentifier]'S-1-5-32-544')
}

function F-Fecha($d) { if ($d) { try { return ([datetime]$d).ToString('yyyy-MM-dd HH:mm:ss') } catch { return "$d" } } else { return $null } }
function F-GB($b) { if ($b -eq $null) { return $null } return [math]::Round($b / 1GB, 1) }
function Corta($s, $n) { if ($s -eq $null) { return '' } $s = "$s" -replace "`r?`n", ' '; if ($s.Length -gt $n) { return $s.Substring(0, $n) + '…' } return $s }
function Desde-Chrome($us) { if (-not $us) { return $null } try { return (Get-Date '1601-01-01').AddTicks([long]$us * 10).ToLocalTime().ToString('yyyy-MM-dd HH:mm') } catch { return $null } }

$script:AuroraProgreso = $null
function Set-AuroraProgreso([scriptblock]$Callback) { $script:AuroraProgreso = $Callback }  # recibe (nombre, ms, error)

function Invoke-Seccion([string]$Nombre, [scriptblock]$Bloque) {
  $sw = [Diagnostics.Stopwatch]::StartNew()
  try { $r = & $Bloque; $err = $null } catch { $r = $null; $err = $_.Exception.Message }
  $sw.Stop()
  if ($script:AuroraProgreso) { try { & $script:AuroraProgreso $Nombre $sw.ElapsedMilliseconds $err } catch {} }
  return [ordered]@{ datos = $r; error = $err; ms = $sw.ElapsedMilliseconds }
}

function Leer-Json($ruta) { if (-not (Test-Path $ruta)) { return $null } try { return (Get-Content $ruta -Raw -Encoding UTF8 | ConvertFrom-Json) } catch { return $null } }

# ---------- secciones ----------

function Get-SeccionSistema {
  $os = Get-CimInstance Win32_OperatingSystem
  $cs = Get-CimInstance Win32_ComputerSystem
  $cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
  $gpu = @(Get-CimInstance Win32_VideoController | ForEach-Object { $_.Name })
  $bios = Get-CimInstance Win32_BIOS
  $bb = Get-CimInstance Win32_BaseBoard
  $boot = $os.LastBootUpTime
  $up = (Get-Date) - $boot
  $bat = Get-CimInstance Win32_Battery | Select-Object -First 1
  [ordered]@{
    equipo        = $env:COMPUTERNAME
    usuario       = "$env:USERDOMAIN\$env:USERNAME"
    es_admin      = (Test-EsAdmin)
    so            = $os.Caption
    version       = "$($os.Version) (build $($os.BuildNumber))"
    instalado     = F-Fecha $os.InstallDate
    ultimo_arranque = F-Fecha $boot
    uptime        = ('{0}d {1}h {2}m' -f $up.Days, $up.Hours, $up.Minutes)
    fabricante    = "$($cs.Manufacturer) $($cs.Model)".Trim()
    placa         = "$($bb.Manufacturer) $($bb.Product)".Trim()
    bios          = "$($bios.SMBIOSBIOSVersion) ($(F-Fecha $bios.ReleaseDate))"
    cpu           = $cpu.Name
    nucleos       = "$($cpu.NumberOfCores) núcleos / $($cpu.NumberOfLogicalProcessors) hilos"
    cpu_carga     = $cpu.LoadPercentage
    ram_total_gb  = F-GB ($os.TotalVisibleMemorySize * 1KB)
    ram_libre_gb  = F-GB ($os.FreePhysicalMemory * 1KB)
    ram_uso_pct   = [math]::Round(100 - ($os.FreePhysicalMemory / $os.TotalVisibleMemorySize * 100), 0)
    gpu           = $gpu
    bateria       = $(if ($bat) { "$($bat.EstimatedChargeRemaining)% (estado $($bat.BatteryStatus))" } else { 'sin batería (escritorio)' })
    zona_horaria  = (Get-TimeZone).Id
    hora_recoleccion = F-Fecha (Get-Date)
  }
}

function Get-SeccionDiscos {
  $logicos = @(Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' | ForEach-Object {
    [ordered]@{ unidad = $_.DeviceID; etiqueta = $_.VolumeName; fs = $_.FileSystem
      total_gb = F-GB $_.Size; libre_gb = F-GB $_.FreeSpace
      libre_pct = $(if ($_.Size) { [math]::Round($_.FreeSpace / $_.Size * 100, 0) } else { $null }) }
  })
  $fisicos = @(Get-PhysicalDisk | ForEach-Object {
    [ordered]@{ nombre = $_.FriendlyName; tipo = "$($_.MediaType)"; bus = "$($_.BusType)"; salud = "$($_.HealthStatus)"; estado = ($_.OperationalStatus -join ','); tam_gb = F-GB $_.Size }
  })
  $smart = @(Get-PhysicalDisk | Get-StorageReliabilityCounter | ForEach-Object {
    [ordered]@{ id = $_.DeviceId; temp_c = $_.Temperature; horas = $_.PowerOnHours; errores_lectura = $_.ReadErrorsTotal; desgaste = $_.Wear }
  })
  [ordered]@{ volumenes = $logicos; fisicos = $fisicos; fiabilidad = $smart }
}

function Get-SeccionArranques {
  $desde = (Get-Date).AddDays(-7)
  $ev = @(Get-WinEvent -FilterHashtable @{LogName = 'System'; Id = 1074, 6005, 6006, 6008, 41, 1001; StartTime = $desde } | ForEach-Object {
    $tipo = switch ($_.Id) { 1074 { 'solicitud' } 6005 { 'inicio' } 6006 { 'apagado limpio' } 6008 { 'apagado inesperado' } 41 { 'reinicio sin apagar (Kernel-Power 41)' } 1001 { 'bugcheck' } }
    $m = $_.Message
    $quien = ''
    if ($_.Id -eq 1074) {
      $x = [xml]$_.ToXml(); $d = @($x.Event.EventData.Data)
      $quien = "$(Corta $d[0].'#text' 60) · usuario $($d[6].'#text') · motivo $($d[4].'#text') · $($d[2].'#text')"
    }
    if ($_.Id -eq 1001 -and $_.ProviderName -notmatch 'BugCheck|WER-SystemErrorReporter') { return }
    [ordered]@{ hora = F-Fecha $_.TimeCreated; id = $_.Id; tipo = $tipo; detalle = $(if ($quien) { $quien } else { Corta $m 160 }) }
  } | Where-Object { $_ } )
  $inesperados = @($ev | Where-Object { $_.id -in 6008, 41 }).Count
  [ordered]@{ eventos = $ev; apagados_inesperados_7d = $inesperados; arranques_7d = @($ev | Where-Object { $_.id -eq 6005 }).Count }
}

function Get-SeccionSeguridad {
  $mp = Get-MpComputerStatus
  $amen = @(Get-MpThreatDetection | Sort-Object InitialDetectionTime -Descending | Select-Object -First 10 | ForEach-Object {
    [ordered]@{ hora = F-Fecha $_.InitialDetectionTime; proceso = $_.ProcessName; recurso = Corta ($_.Resources -join ';') 160 } })
  $fw = @(Get-NetFirewallProfile | ForEach-Object { [ordered]@{ perfil = $_.Name; activo = [bool]$_.Enabled; entrada_defecto = "$($_.DefaultInboundAction)" } })
  $redes = @(Get-NetConnectionProfile | ForEach-Object { [ordered]@{ red = $_.Name; categoria = "$($_.NetworkCategory)"; adaptador = $_.InterfaceAlias } })
  $rdp = (Get-ItemProperty 'HKLM:\System\CurrentControlSet\Control\Terminal Server').fDenyTSConnections
  $puertos = @(Get-NetTCPConnection -State Listen | Where-Object { $_.LocalAddress -notin '127.0.0.1', '::1' } | Sort-Object LocalPort -Unique | Select-Object -First 60 | ForEach-Object {
    $pr = Get-Process -Id $_.OwningProcess
    [ordered]@{ puerto = $_.LocalPort; direccion = $_.LocalAddress; pid = $_.OwningProcess; proceso = $pr.Name; ruta = $pr.Path }
  })
  $sensibles = @($puertos | Where-Object { $_.puerto -in 21, 22, 23, 135, 139, 445, 1433, 3306, 3389, 5900, 5938, 5985, 5986, 8080 })
  # política de bloqueo
  $pol = [ordered]@{}
  $na = net accounts 2>$null
  foreach ($l in $na) { if ($l -match '^(.*?):\s+(.*)$') { $pol[$Matches[1].Trim()] = $Matches[2].Trim() } }
  # logons fallidos / bloqueos (requiere admin)
  $fallidos = @(); $bloqueos = @(); $sec_err = $null
  try {
    $evs = @(Get-WinEvent -FilterHashtable @{LogName = 'Security'; Id = 4625, 4740; StartTime = (Get-Date).AddDays(-7) } -MaxEvents 600 -ErrorAction Stop)
    $tmp = foreach ($e in $evs) {
      $x = [xml]$e.ToXml(); $d = @{}; foreach ($n in $x.Event.EventData.Data) { $d[$n.Name] = $n.'#text' }
      if ($e.Id -eq 4740) { $bloqueos += [ordered]@{ hora = F-Fecha $e.TimeCreated; cuenta = $d['TargetUserName']; equipo_llamador = $d['TargetDomainName'] } }
      else {
        [pscustomobject]@{ hora = $e.TimeCreated; cuenta = $d['TargetUserName']; tipo = $d['LogonType']; proceso = $(if ($d['ProcessName']) { Split-Path $d['ProcessName'] -Leaf } else { '-' }); ip = $d['IpAddress']; sub = $d['SubStatus'] }
      }
    }
    $fallidos = @($tmp | Group-Object cuenta, tipo, proceso, ip | ForEach-Object {
      $g = $_.Group | Sort-Object hora
      [ordered]@{ cuenta = $g[0].cuenta; tipo_logon = $g[0].tipo; proceso = $g[0].proceso; ip = $g[0].ip; veces = $_.Count; primero = F-Fecha $g[0].hora; ultimo = F-Fecha $g[-1].hora; subestado = $g[-1].sub }
    } | Sort-Object veces -Descending)
  } catch { $sec_err = 'El registro de Seguridad no se pudo leer. Ejecuta el diagnóstico como administrador.' }
  [ordered]@{
    defender = [ordered]@{ antivirus = $mp.AntivirusEnabled; tiempo_real = $mp.RealTimeProtectionEnabled; firmas = F-Fecha $mp.AntivirusSignatureLastUpdated
      firmas_edad_dias = $mp.AntivirusSignatureAge; ultimo_rapido = F-Fecha $mp.QuickScanEndTime; ultimo_completo = F-Fecha $mp.FullScanEndTime; tamper = $mp.IsTamperProtected }
    amenazas = $amen; firewall = $fw; redes = $redes; rdp_habilitado = ($rdp -eq 0); puertos_escucha = $puertos; puertos_sensibles = $sensibles
    politica_bloqueo = $pol; logons_fallidos_7d = $fallidos; bloqueos_7d = $bloqueos; seguridad_error = $sec_err
  }
}

function Get-SeccionCuentas {
  $adminsSid = 'S-1-5-32-544'
  $admins = @()
  try { $admins = @(Get-LocalGroupMember -SID $adminsSid | ForEach-Object { "$($_.Name) ($($_.PrincipalSource))" }) } catch {}
  $users = @(Get-LocalUser | ForEach-Object {
    [ordered]@{ nombre = $_.Name; activa = $_.Enabled; origen = "$($_.PrincipalSource)"; ultimo_logon = F-Fecha $_.LastLogon; clave_requerida = $_.PasswordRequired; clave_cambiada = F-Fecha $_.PasswordLastSet } })
  [ordered]@{ usuarios = $users; administradores = $admins }
}

function Get-SeccionRed {
  $ips = @(Get-NetIPConfiguration | Where-Object { $_.IPv4Address } | ForEach-Object {
    [ordered]@{ adaptador = $_.InterfaceAlias; ipv4 = ($_.IPv4Address.IPAddress -join ','); puerta = ($_.IPv4DefaultGateway.NextHop -join ','); dns = ($_.DNSServer.ServerAddresses -join ','); estado = "$($_.NetAdapter.Status)" } })
  $gw = ($ips | Where-Object { $_.puerta } | Select-Object -First 1).puerta
  $ping = $null
  if ($gw) { try { $pg = New-Object System.Net.NetworkInformation.Ping; $ping = ($pg.Send($gw, 1500).Status -eq 'Success') } catch { $ping = $false } }
  $internet = $null
  try { $tc = New-Object System.Net.Sockets.TcpClient; $t = $tc.ConnectAsync('www.msftconnecttest.com', 80); $internet = ($t.Wait(2500) -and $tc.Connected); $tc.Close() } catch { $internet = $false }
  $wifi = @(netsh wlan show interfaces 2>$null | Select-String 'SSID|Señal|Signal|Estado|State' | ForEach-Object { $_.Line.Trim() })
  $est = @(Get-NetTCPConnection -State Established | Where-Object { $_.RemoteAddress -notmatch '^(127\.|::1|0\.0\.0\.0|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)' } | Group-Object OwningProcess | ForEach-Object {
    $pr = Get-Process -Id $_.Name; [ordered]@{ proceso = $pr.Name; pid = [int]$_.Name; conexiones = $_.Count; destinos = Corta (($_.Group | Select-Object -First 4 | ForEach-Object { "$($_.RemoteAddress):$($_.RemotePort)" }) -join ' ') 120 } } | Sort-Object conexiones -Descending | Select-Object -First 25)
  [ordered]@{ adaptadores = $ips; puerta_responde = $ping; internet = $internet; wifi = $wifi; conexiones_salientes = $est }
}

function Get-SeccionPersistencia {
  $run = @()
  foreach ($k in 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run', 'HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce', 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Run', 'HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce', 'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run') {
    if (Test-Path $k) { (Get-ItemProperty $k).PSObject.Properties | Where-Object { $_.Name -notmatch '^PS' } | ForEach-Object {
        $v = "$($_.Value)"; $run += [ordered]@{ clave = ($k -replace 'HKEY_|:\\Software\\Microsoft\\Windows\\CurrentVersion', ''); nombre = $_.Name; comando = Corta $v 180; sospechoso = ($v -match 'AppData\\Local\\Temp|\\Downloads\\|\\Public\\|powershell|wscript|cscript|mshta|rundll32|regsvr32|cmd\.exe|-enc|bitsadmin|certutil') } } }
  }
  $inicio = @()
  foreach ($c in "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup", "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp") {
    Get-ChildItem $c -File | ForEach-Object { $inicio += [ordered]@{ archivo = $_.Name; carpeta = $c; modificado = F-Fecha $_.LastWriteTime } } }
  $tareas = @(Get-ScheduledTask | Where-Object { $_.TaskPath -notlike '\Microsoft\*' } | ForEach-Object {
    $acc = (($_.Actions | ForEach-Object { "$($_.Execute) $($_.Arguments)" }) -join ' ; ').Trim()
    $i = Get-ScheduledTaskInfo $_
    [ordered]@{ tarea = "$($_.TaskPath)$($_.TaskName)"; estado = "$($_.State)"; ultima = F-Fecha $i.LastRunTime; accion = Corta $acc 160; autor = $_.Author; sospechosa = ($acc -match 'AppData\\Local\\Temp|\\Downloads\\|\\Public\\|powershell.*-enc|wscript|cscript|mshta') } })
  $servicios = @(Get-CimInstance Win32_Service | Where-Object { $_.PathName -and $_.PathName -notmatch '\\Windows\\' } | ForEach-Object {
    [ordered]@{ servicio = $_.Name; nombre = $_.DisplayName; estado = $_.State; inicio = $_.StartMode; ruta = Corta $_.PathName 160; cuenta = $_.StartName } })
  $hace30 = (Get-Date).AddDays(-30)
  $progs = @(Get-ItemProperty 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*', 'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*', 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*' | Where-Object { $_.DisplayName -and $_.InstallDate } | ForEach-Object {
    $f = $null; try { $f = [datetime]::ParseExact($_.InstallDate, 'yyyyMMdd', $null) } catch {}
    if ($f -and $f -gt $hace30) { [ordered]@{ programa = $_.DisplayName; version = $_.DisplayVersion; editor = $_.Publisher; fecha = $f.ToString('yyyy-MM-dd') } } } | Sort-Object fecha -Descending)
  [ordered]@{ run = $run; carpeta_inicio = $inicio; tareas = $tareas; servicios_terceros = $servicios; programas_30d = $progs }
}

function Get-SeccionProcesos {
  $n = (Get-CimInstance Win32_ComputerSystem).NumberOfLogicalProcessors
  $a = @{}; Get-Process | ForEach-Object { $a[$_.Id] = $_.CPU }
  Start-Sleep -Milliseconds 800
  $procs = Get-Process
  $top = @($procs | ForEach-Object {
    $prev = $a[$_.Id]; $pct = $null
    if ($prev -ne $null -and $_.CPU -ne $null) { $pct = [math]::Round(($_.CPU - $prev) / 0.8 / $n * 100, 1); if ($pct -lt 0) { $pct = 0 } }
    [pscustomobject]@{ nombre = $_.Name; pid = $_.Id; cpu_pct = $pct; ram_mb = [math]::Round($_.WorkingSet64 / 1MB, 0); ruta = $_.Path; inicio = $_.StartTime }
  })
  $topcpu = @($top | Sort-Object cpu_pct -Descending | Select-Object -First 10 | ForEach-Object { [ordered]@{ nombre = $_.nombre; pid = $_.pid; cpu_pct = $_.cpu_pct; ram_mb = $_.ram_mb } })
  $topram = @($top | Sort-Object ram_mb -Descending | Select-Object -First 10 | ForEach-Object { [ordered]@{ nombre = $_.nombre; pid = $_.pid; cpu_pct = $_.cpu_pct; ram_mb = $_.ram_mb } })
  # Firmas: solo fuera de Windows\ y de los paquetes de la Tienda (MSIX firma el paquete, no el exe)
  $rutas = @($top | Where-Object { $_.ruta -and $_.ruta -notmatch '^[A-Z]:\\Windows\\|\\WindowsApps\\' } | Select-Object -ExpandProperty ruta -Unique | Select-Object -First 80)
  $firmas = @{}
  foreach ($r in $rutas) { $s = Get-AuthenticodeSignature -FilePath $r; $firmas[$r] = [ordered]@{ estado = "$($s.Status)"; firmante = $(if ($s.SignerCertificate) { ($s.SignerCertificate.Subject -replace '^CN=([^,]+).*', '$1') } else { '' }) } }
  $sosp = @($top | Where-Object { $_.ruta -and ($_.ruta -match 'AppData\\Local\\Temp|\\Downloads\\|\\Public\\|ProgramData\\[^\\]+\\[^\\]+\.exe$|\\Users\\[^\\]+\\[^\\]+\.exe$' -or ($firmas.ContainsKey($_.ruta) -and $firmas[$_.ruta].estado -eq 'NotSigned')) } | Group-Object ruta | ForEach-Object {
    $g = $_.Group[0]; $f = $firmas[$_.Name]
    [ordered]@{ nombre = $g.nombre; pid = (($_.Group | ForEach-Object { $_.pid }) -join ','); ruta = $_.Name; firma = $(if ($f) { $f.estado } else { 'no comprobada' }); firmante = $(if ($f) { $f.firmante } else { '' }) } })
  [ordered]@{ total = $procs.Count; top_cpu = $topcpu; top_ram = $topram; sospechosos = $sosp; sin_firma_total = @($firmas.Values | Where-Object { $_.estado -eq 'NotSigned' }).Count }
}

function Get-SeccionCrashes {
  $desde = (Get-Date).AddDays(-7)
  $apps = @(Get-WinEvent -FilterHashtable @{LogName = 'Application'; Id = 1000; StartTime = $desde } -MaxEvents 300 | ForEach-Object {
    $x = [xml]$_.ToXml(); $d = @($x.Event.EventData.Data | ForEach-Object { if ($_ -is [string]) { $_ } else { $_.InnerText } })
    $app = $(if ($_.ProviderName -eq 'Application Error' -and $d.Count) { $d[0] } else { "$($_.ProviderName): $(Corta $_.Message 60)" })
    [pscustomobject]@{ app = $app; modulo = $(if ($d.Count -gt 3) { $d[3] } else { '' }); hora = $_.TimeCreated } } | Group-Object app | ForEach-Object {
    $g = $_.Group | Sort-Object hora; [ordered]@{ aplicacion = $_.Name; veces = $_.Count; ultimo = F-Fecha $g[-1].hora; modulo = $g[-1].modulo } } | Sort-Object veces -Descending)
  $wer = @(Get-WinEvent -FilterHashtable @{LogName = 'Application'; ProviderName = 'Windows Error Reporting'; Id = 1001; StartTime = $desde } -MaxEvents 400 | ForEach-Object {
    $x = [xml]$_.ToXml(); $d = @($x.Event.EventData.Data | ForEach-Object { if ($_ -is [string]) { $_ } else { $_.InnerText } }); $(if ($d.Count -gt 2) { $d[2] } else { '?' }) } | Group-Object | ForEach-Object { [ordered]@{ evento = $_.Name; veces = $_.Count } } | Sort-Object veces -Descending | Select-Object -First 10)
  # sin -Recurse: LiveKernelReports con recursión puede tardar minutos por permisos
  $dumps = @(Get-ChildItem 'C:\Windows\Minidump\*.dmp', 'C:\Windows\MEMORY.DMP', 'C:\Windows\LiveKernelReports\*.dmp', 'C:\Windows\LiveKernelReports\*\*.dmp' -File | Sort-Object LastWriteTime -Descending | Select-Object -First 10 | ForEach-Object { [ordered]@{ archivo = $_.FullName; fecha = F-Fecha $_.LastWriteTime; mb = [math]::Round($_.Length / 1MB, 1) } })
  $criticos = @(Get-WinEvent -FilterHashtable @{LogName = 'System'; Level = 1, 2; StartTime = (Get-Date).AddHours(-48) } -MaxEvents 300 | Where-Object { $_.ProviderName -notmatch 'DistributedCOM|Kernel-Power|EventLog' } | Group-Object ProviderName, Id | ForEach-Object {
    $g = $_.Group | Sort-Object TimeCreated; [ordered]@{ origen = $g[0].ProviderName; id = $g[0].Id; veces = $_.Count; ultimo = F-Fecha $g[-1].TimeCreated; mensaje = Corta $g[-1].Message 180 } } | Sort-Object veces -Descending | Select-Object -First 15)
  [ordered]@{ apps_7d = $apps; wer_7d = $wer; volcados = $dumps; sistema_errores_48h = $criticos }
}

function Get-PerfilesNavegador($raiz, $nombre) {
  $ls = Leer-Json "$raiz\Local State"
  if (-not $ls) { return @() }
  $out = @()
  foreach ($p in $ls.profile.info_cache.PSObject.Properties) {
    $dir = Join-Path $raiz $p.Name
    $pref = Leer-Json "$dir\Preferences"; $sp = Leer-Json "$dir\Secure Preferences"
    $exts = @()
    foreach ($src in @($sp.extensions.settings, $pref.extensions.settings)) {
      if (-not $src) { continue }
      foreach ($e in $src.PSObject.Properties) {
        $v = $e.Value; if (-not $v.manifest) { continue }
        if ($v.location -in 5, 10) { continue } # componentes internos
        # location: 1 tienda/crx, 2-3 externas por registro/pref, 4 descomprimida (modo desarrollador), 6/8 instaladas por política o Google
        $fuera = ($v.location -eq 4) -or ($v.location -in 2, 3) -or ($v.location -eq 1 -and -not $v.from_webstore -and $nombre -eq 'Chrome')
        $exts += [ordered]@{ id = $e.Name; nombre = $v.manifest.name; version = $v.manifest.version; tienda = [bool]$v.from_webstore; ubicacion = $v.location; fuera_tienda = $fuera; instalada = Desde-Chrome $v.first_install_time; permisos = Corta (($v.granted_permissions.api -join ',')) 120 }
      }
    }
    $exts = @($exts | Sort-Object id -Unique)
    $out += [ordered]@{
      navegador = $nombre; carpeta = $p.Name; nombre = $p.Value.name; cuenta = $p.Value.user_name; activo = Desde-Chrome $p.Value.active_time
      salida = $pref.profile.exit_type
      hello_al_rellenar = [bool]$pref.password_manager.biometric_authentication_filling
      extensiones = $exts; extensiones_fuera_tienda = @($exts | Where-Object { $_.fuera_tienda }).Count
    }
  }
  return $out
}

function Get-SeccionNavegadores {
  $perf = @()
  $perf += Get-PerfilesNavegador "$env:LOCALAPPDATA\Google\Chrome\User Data" 'Chrome'
  $perf += Get-PerfilesNavegador "$env:LOCALAPPDATA\Microsoft\Edge\User Data" 'Edge'
  $perf += Get-PerfilesNavegador "$env:LOCALAPPDATA\BraveSoftware\Brave-Browser\User Data" 'Brave'
  [ordered]@{ perfiles = $perf; total_perfiles = $perf.Count }
}

function Get-SeccionActualizaciones {
  $hot = @(Get-HotFix | Sort-Object InstalledOn -Descending | Select-Object -First 8 | ForEach-Object { [ordered]@{ kb = $_.HotFixID; tipo = $_.Description; fecha = F-Fecha $_.InstalledOn } })
  $pend = (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending') -or (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired')
  $hist = @()
  try { $s = New-Object -ComObject Microsoft.Update.Session; $hist = @($s.CreateUpdateSearcher().QueryHistory(0, 12) | ForEach-Object { [ordered]@{ fecha = F-Fecha $_.Date; resultado = $(switch ($_.ResultCode) { 2 { 'ok' } 3 { 'ok con errores' } 4 { 'falló' } 5 { 'cancelada' } default { "$($_.ResultCode)" } }); titulo = Corta $_.Title 110 } }) } catch {}
  $chrome = $null; $cp = "$env:LOCALAPPDATA\Google\Chrome\User Data\Last Version"; if (Test-Path $cp) { $chrome = (Get-Content $cp -Raw).Trim() }
  [ordered]@{ hotfix = $hot; reinicio_pendiente = $pend; historial = $hist; chrome_version = $chrome }
}

function Get-SeccionRendimiento {
  # Las causas típicas de «PC lenta»: disco mecánico, disco saturado, arranque cargado, RAM corta, plan de energía
  $plan = (powercfg /getactivescheme 2>$null) -join ' '
  if ($plan -match '\((.+)\)') { $plan = $Matches[1] } else { $plan = Corta $plan 60 }
  $sistema = $null
  try { $disco = Get-Partition -DriveLetter ($env:SystemDrive.TrimEnd(':')) | Get-Disk; $pd = Get-PhysicalDisk | Where-Object { $_.DeviceId -eq "$($disco.Number)" }; $sistema = [ordered]@{ nombre = $pd.FriendlyName; tipo = "$($pd.MediaType)"; bus = "$($pd.BusType)" } } catch {}
  $perf = Get-CimInstance Win32_PerfFormattedData_PerfDisk_PhysicalDisk -Filter "Name='_Total'"
  $disco_pct = $null; $cola = $null
  if ($perf) { $disco_pct = [math]::Min(100, [int]$perf.PercentDiskTime); $cola = [math]::Round($perf.AvgDiskQueueLength, 1) }
  $pf = Get-CimInstance Win32_PageFileUsage | Select-Object -First 1
  $cs = Get-CimInstance Win32_ComputerSystem
  # apps de arranque habilitadas (lo que muestra el Administrador de tareas → Inicio)
  $habilitadas = @()
  foreach ($k in 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run', 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\StartupFolder', 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run') {
    if (Test-Path $k) { (Get-ItemProperty $k).PSObject.Properties | Where-Object { $_.Name -notmatch '^PS' } | ForEach-Object { $v = $_.Value; if ($v -is [byte[]] -and $v.Length -gt 0 -and ($v[0] -eq 2 -or $v[0] -eq 6)) { $habilitadas += $_.Name } } }
  }
  $buscador = (Get-Service WSearch -ErrorAction SilentlyContinue).Status
  $sysmain = (Get-Service SysMain -ErrorAction SilentlyContinue).Status
  $trim = $null; try { $t = fsutil behavior query DisableDeleteNotify 2>$null; if ("$t" -match 'NTFS\s*DisableDeleteNotify\s*=\s*(\d)') { $trim = ($Matches[1] -eq '0') } } catch {}
  [ordered]@{
    plan_energia = $plan; disco_sistema = $sistema; disco_ocupado_pct = $disco_pct; disco_cola = $cola
    ram_total_gb = F-GB $cs.TotalPhysicalMemory
    pagefile_uso_mb = $(if ($pf) { $pf.CurrentUsage } else { $null }); pagefile_mb = $(if ($pf) { $pf.AllocatedBaseSize } else { $null })
    arranque_habilitadas = @($habilitadas | Sort-Object -Unique); arranque_total = @($habilitadas | Sort-Object -Unique).Count
    windows_search = "$buscador"; sysmain = "$sysmain"; trim_activo = $trim
  }
}

# ---------- hallazgos ----------

function Get-Hallazgos($d) {
  $h = New-Object System.Collections.ArrayList
  function Add-H($nivel, $titulo, $detalle, $accion) { [void]$h.Add([ordered]@{ nivel = $nivel; titulo = $titulo; detalle = $detalle; accion = $accion }) }
  $s = $d.sistema.datos; $sec = $d.seguridad.datos; $nav = $d.navegadores.datos; $arr = $d.arranques.datos; $dis = $d.discos.datos; $pr = $d.procesos.datos; $per = $d.persistencia.datos; $act = $d.actualizaciones.datos; $red = $d.red.datos

  if ($s -and -not $s.es_admin) { Add-H 'aviso' 'Recolección sin administrador' 'El registro de seguridad, SMART y algunos servicios no se pudieron leer.' 'Vuelve a ejecutar el diagnóstico con clic derecho → Ejecutar como administrador.' }

  if ($sec) {
    $df = $sec.defender
    if ($df.antivirus -ne $true -or $df.tiempo_real -ne $true) { Add-H 'critico' 'Microsoft Defender desactivado' "Antivirus=$($df.antivirus), tiempo real=$($df.tiempo_real)." 'Activa la protección en tiempo real en Seguridad de Windows o revisa si otro antivirus la reemplaza.' }
    else { Add-H 'ok' 'Defender activo con protección en tiempo real' "Firmas del $($df.firmas)." $null }
    if ($df.firmas_edad_dias -gt 7) { Add-H 'aviso' 'Firmas de Defender desactualizadas' "Tienen $($df.firmas_edad_dias) días." 'Busca actualizaciones en Seguridad de Windows.' }
    if (-not $df.ultimo_completo -or ([datetime]$df.ultimo_completo) -lt (Get-Date).AddDays(-30)) { Add-H 'aviso' 'Sin examen completo reciente' "Último completo: $(if ($df.ultimo_completo) { $df.ultimo_completo } else { 'nunca' })." 'Ejecuta un Examen completo desde Seguridad de Windows.' }
    if ($sec.amenazas.Count -gt 0) { Add-H 'critico' 'Defender registró amenazas' "$($sec.amenazas.Count) detecciones recientes; la última el $($sec.amenazas[0].hora)." 'Revisa el Historial de protección y confirma que están en cuarentena.' }
    $fwoff = @($sec.firewall | Where-Object { -not $_.activo })
    if ($fwoff.Count) { Add-H 'critico' 'Firewall desactivado' ("Perfiles: " + (($fwoff | ForEach-Object { $_.perfil }) -join ', ')) 'Actívalo en Seguridad de Windows → Firewall.' } else { Add-H 'ok' 'Firewall activo en todos los perfiles' $null $null }
    $pub = @($sec.redes | Where-Object { $_.categoria -eq 'Public' })
    if ($pub.Count) { Add-H 'info' 'Red marcada como Pública' ("Red: " + (($pub | ForEach-Object { $_.red }) -join ', ') + '. Es lo más seguro, pero bloquea el agente y SSH de Aurora Diagnóstico.') 'Si es tu red de casa y quieres usar el panel remoto, cámbiala a Privada en Configuración → Red.' }
    if ($sec.rdp_habilitado) { Add-H $(if ($pub.Count) { 'critico' } else { 'aviso' }) 'Escritorio remoto (RDP) habilitado' 'RDP expone el puerto 3389.' 'Si no lo usas, desactívalo en Configuración → Sistema → Escritorio remoto.' }
    if ($sec.puertos_sensibles.Count) { Add-H 'info' 'Puertos sensibles en escucha' (($sec.puertos_sensibles | ForEach-Object { "$($_.puerto)/$($_.proceso)" }) -join ', ') 'Normal si reconoces el proceso (445 = compartir archivos de Windows).' }
    if ($sec.bloqueos_7d.Count) {
      $top = $sec.logons_fallidos_7d | Select-Object -First 1
      Add-H 'aviso' 'La cuenta se bloqueó por intentos fallidos' "$($sec.bloqueos_7d.Count) bloqueo(s) en 7 días; el origen con más intentos fue '$($top.proceso)' ($($top.veces) veces, tipo $($top.tipo_logon))." 'Si el proceso es chrome.exe o msedgewebview2.exe suele ser la verificación del gestor de contraseñas, no un ataque. Si es un tipo de inicio 3 con IP externa, cambia la contraseña de Windows.' }
    $redFail = @($sec.logons_fallidos_7d | Where-Object { $_.tipo_logon -in '3', '10' -and $_.ip -and $_.ip -notin '-', '127.0.0.1', '::1' })
    if ($redFail.Count) { $tot = ($redFail | Measure-Object veces -Sum).Sum; Add-H $(if ($tot -gt 20) { 'critico' } else { 'aviso' }) 'Intentos de inicio de sesión por red' "$tot intentos fallidos desde: $(($redFail | Select-Object -First 5 | ForEach-Object { $_.ip }) -join ', ')." 'Alguien prueba contraseñas contra este equipo. Asegura una contraseña fuerte y revisa el router.' }
    if ($sec.seguridad_error) { Add-H 'info' 'Registro de seguridad no leído' $sec.seguridad_error $null }
  }
  if ($nav) {
    $hello = @($nav.perfiles | Where-Object { $_.hello_al_rellenar })
    if ($hello.Count) { Add-H 'aviso' 'Chrome verifica tu identidad al rellenar contraseñas' ("Perfiles: " + (($hello | ForEach-Object { "$($_.navegador)/$($_.nombre)" }) -join ', ') + '. Cada verificación genera un intento de contraseña fallido en Windows y 10 en 10 minutos bloquean la cuenta.') 'En chrome://password-manager/settings desactiva «Usar Windows Hello al rellenar contraseñas».' }
    $fuera = @($nav.perfiles | Where-Object { $_.extensiones_fuera_tienda -gt 0 })
    if ($fuera.Count) { Add-H 'aviso' 'Extensiones instaladas fuera de la tienda' (($fuera | ForEach-Object { "$($_.navegador)/$($_.nombre): " + (($_.extensiones | Where-Object { $_.fuera_tienda } | ForEach-Object { $_.nombre }) -join ', ') }) -join ' · ') 'Revisa cada una en chrome://extensions y elimina las que no reconozcas.' }
    $crash = @($nav.perfiles | Where-Object { $_.salida -eq 'Crashed' })
    if ($crash.Count) { Add-H 'info' 'Perfiles de navegador cerrados de forma brusca' (($crash | ForEach-Object { "$($_.navegador)/$($_.nombre)" }) -join ', ') 'Puede deberse a un reinicio o a un cierre forzado; las sesiones temporales se pierden.' }
  }
  if ($arr) {
    if ($arr.apagados_inesperados_7d -gt 0) { Add-H 'aviso' 'Apagados inesperados' "$($arr.apagados_inesperados_7d) en los últimos 7 días (corte de luz, cuelgue o botón de encendido)." 'Si se repiten sin corte de luz, revisa temperatura, fuente y memoria.' }
    if ($arr.arranques_7d -gt 10) { Add-H 'info' 'Muchos reinicios' "$($arr.arranques_7d) arranques en 7 días." $null }
  }
  if ($dis) {
    foreach ($v in $dis.volumenes) { if ($v.libre_pct -ne $null -and $v.libre_pct -lt 10) { Add-H $(if ($v.libre_pct -lt 5) { 'critico' } else { 'aviso' }) "Poco espacio en $($v.unidad)" "$($v.libre_gb) GB libres ($($v.libre_pct)%)." 'Libera espacio: Configuración → Sistema → Almacenamiento.' } }
    foreach ($f in $dis.fisicos) { if ($f.salud -and $f.salud -ne 'Healthy') { Add-H 'critico' "Disco con problemas: $($f.nombre)" "Salud: $($f.salud) · $($f.estado)." 'Haz copia de seguridad ya y reemplaza el disco.' } }
    foreach ($r in $dis.fiabilidad) { if ($r.temp_c -gt 60) { Add-H 'aviso' 'Disco caliente' "Disco $($r.id) a $($r.temp_c) °C." 'Revisa ventilación.' } }
  }
  if ($s -and $s.ram_uso_pct -ge 90) { Add-H 'aviso' 'Memoria RAM casi llena' "$($s.ram_uso_pct)% en uso." 'Cierra programas o revisa los procesos con más RAM.' }
  $rd = $d.rendimiento.datos
  if ($rd) {
    if ($rd.disco_sistema -and $rd.disco_sistema.tipo -eq 'HDD') { Add-H 'aviso' 'Windows está en un disco mecánico (HDD)' "Disco del sistema: $($rd.disco_sistema.nombre). Es la causa más frecuente de lentitud general." 'Migrar Windows a un SSD es la mejora con más impacto: el equipo arranca y abre programas varias veces más rápido.' }
    elseif ($rd.disco_sistema) { Add-H 'ok' 'Windows está en un disco SSD' "$($rd.disco_sistema.nombre)" $null }
    if ($rd.disco_ocupado_pct -ne $null -and $rd.disco_ocupado_pct -ge 80) { Add-H 'aviso' 'Disco trabajando al límite' "$($rd.disco_ocupado_pct)% de actividad en el momento de la revisión (cola $($rd.disco_cola))." 'Si se mantiene así, revisa qué proceso lo usa: Windows Search, Defender, OneDrive o actualizaciones.' }
    if ($rd.ram_total_gb -and $rd.ram_total_gb -lt 8) { Add-H 'aviso' 'Poca memoria RAM' "$($rd.ram_total_gb) GB instalados; hoy Windows y el navegador piden 8 GB como mínimo cómodo." 'Ampliar a 8 o 16 GB evita que el equipo se arrastre con varias pestañas abiertas.' }
    if ($rd.arranque_total -gt 8) { Add-H 'aviso' 'Muchos programas arrancan con Windows' "$($rd.arranque_total) habilitados: $(($rd.arranque_habilitadas | Select-Object -First 8) -join ', ')." 'Desactiva los que no uses a diario en Administrador de tareas → Aplicaciones de inicio.' }
    if ($rd.plan_energia -match 'conom|saver|ahorro') { Add-H 'info' 'Plan de energía en modo ahorro' "Plan activo: $($rd.plan_energia)." 'En un PC de escritorio conviene «Equilibrado» o «Alto rendimiento».' }
    if ($rd.pagefile_uso_mb -gt 2048) { Add-H 'info' 'Uso alto del archivo de paginación' "$($rd.pagefile_uso_mb) MB en uso: el equipo tira de disco porque la RAM no alcanza." 'Reforzar la RAM o cerrar programas pesados.' }
    if ($rd.trim_activo -eq $false -and $rd.disco_sistema -and $rd.disco_sistema.tipo -eq 'SSD') { Add-H 'info' 'TRIM desactivado en el SSD' $null 'Actívalo: fsutil behavior set DisableDeleteNotify 0 (como administrador).' }
  }
  if ($pr -and $pr.sospechosos.Count) { Add-H 'aviso' 'Procesos sin firma o en carpetas temporales' (($pr.sospechosos | Select-Object -First 6 | ForEach-Object { "$($_.nombre) [$($_.firma)]" }) -join ', ') 'Comprueba cada uno; los programas legítimos suelen estar firmados y en Archivos de programa.' }
  if ($per) {
    $rs = @($per.run | Where-Object { $_.sospechoso }) + @($per.tareas | Where-Object { $_.sospechosa })
    if ($rs.Count) { Add-H 'aviso' 'Arranque automático con patrón sospechoso' (($rs | Select-Object -First 5 | ForEach-Object { if ($_.nombre) { $_.nombre } else { $_.tarea } }) -join ', ') 'Revisa esas entradas en el Administrador de tareas → Inicio y en el Programador de tareas.' }
    if ($per.programas_30d.Count) { Add-H 'info' 'Programas instalados en los últimos 30 días' (($per.programas_30d | Select-Object -First 8 | ForEach-Object { $_.programa }) -join ', ') $null }
  }
  if ($act -and $act.reinicio_pendiente) { Add-H 'info' 'Reinicio pendiente por actualizaciones' $null 'Reinicia cuando puedas.' }
  if ($red) { if ($red.internet -eq $false) { Add-H 'aviso' 'Sin salida a internet' "Puerta de enlace responde: $($red.puerta_responde)." 'Revisa router o proveedor.' } }
  if ($d.crashes.datos -and $d.crashes.datos.apps_7d.Count) { $c = $d.crashes.datos.apps_7d[0]; Add-H 'info' 'Aplicaciones que fallaron esta semana' "$($d.crashes.datos.apps_7d.Count) apps; la que más: $($c.aplicacion) ($($c.veces) veces)." $null }

  $crit = @($h | Where-Object { $_.nivel -eq 'critico' }).Count; $av = @($h | Where-Object { $_.nivel -eq 'aviso' }).Count
  $score = [math]::Max(0, 100 - 25 * $crit - 8 * $av)
  $orden = @{ critico = 0; aviso = 1; info = 2; ok = 3 }
  [ordered]@{ puntaje = $score; criticos = $crit; avisos = $av; lista = @($h | Sort-Object { $orden[$_.nivel] }) }
}

# ---------- orquestación ----------

function Get-AuroraDiagnostico {
  [CmdletBinding()] param([switch]$Rapido)
  Write-Verbose 'Recolectando…'
  $d = [ordered]@{
    meta = [ordered]@{ herramienta = 'Aurora Diagnóstico'; version = $script:AuroraVersion; generado = F-Fecha (Get-Date); equipo = $env:COMPUTERNAME; modo = $(if ($Rapido) { 'rapido' } else { 'completo' }) }
    sistema = Invoke-Seccion 'sistema' { Get-SeccionSistema }
    discos = Invoke-Seccion 'discos' { Get-SeccionDiscos }
    arranques = Invoke-Seccion 'arranques' { Get-SeccionArranques }
    seguridad = Invoke-Seccion 'seguridad' { Get-SeccionSeguridad }
    cuentas = Invoke-Seccion 'cuentas' { Get-SeccionCuentas }
    red = Invoke-Seccion 'red' { Get-SeccionRed }
    persistencia = Invoke-Seccion 'persistencia' { Get-SeccionPersistencia }
    rendimiento = Invoke-Seccion 'rendimiento' { Get-SeccionRendimiento }
    procesos = Invoke-Seccion 'procesos' { Get-SeccionProcesos }
    crashes = Invoke-Seccion 'crashes' { Get-SeccionCrashes }
    navegadores = Invoke-Seccion 'navegadores' { Get-SeccionNavegadores }
    actualizaciones = Invoke-Seccion 'actualizaciones' { if ($Rapido) { $null } else { Get-SeccionActualizaciones } }
  }
  $d.hallazgos = Get-Hallazgos $d
  return $d
}

function Get-AuroraEstadoRapido {
  # métricas vivas para el panel del agente (barato, < 1 s)
  $os = Get-CimInstance Win32_OperatingSystem
  $cpu = (Get-CimInstance Win32_Processor | Measure-Object LoadPercentage -Average).Average
  $n = (Get-CimInstance Win32_ComputerSystem).NumberOfLogicalProcessors
  $a = @{}; Get-Process | ForEach-Object { $a[$_.Id] = $_.CPU }
  Start-Sleep -Milliseconds 500
  $top = @(Get-Process | ForEach-Object { $prev = $a[$_.Id]; $pct = 0; if ($prev -ne $null -and $_.CPU -ne $null) { $pct = [math]::Round(($_.CPU - $prev) / 0.5 / $n * 100, 1); if ($pct -lt 0) { $pct = 0 } }
      [pscustomobject]@{ nombre = $_.Name; pid = $_.Id; cpu = $pct; ram = [math]::Round($_.WorkingSet64 / 1MB, 0) } } | Sort-Object cpu, ram -Descending | Select-Object -First 8 | ForEach-Object { [ordered]@{ nombre = $_.nombre; pid = $_.pid; cpu = $_.cpu; ram = $_.ram } })
  $discos = @(Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' | ForEach-Object { [ordered]@{ unidad = $_.DeviceID; total = F-GB $_.Size; libre = F-GB $_.FreeSpace; uso_pct = $(if ($_.Size) { [math]::Round(100 - $_.FreeSpace / $_.Size * 100, 0) } else { 0 }) } })
  $net = @(Get-NetAdapterStatistics | Where-Object { $_.ReceivedBytes -gt 0 } | ForEach-Object { [ordered]@{ adaptador = $_.Name; rx_mb = [math]::Round($_.ReceivedBytes / 1MB, 0); tx_mb = [math]::Round($_.SentBytes / 1MB, 0) } })
  $up = (Get-Date) - $os.LastBootUpTime
  $mp = Get-MpComputerStatus
  [ordered]@{
    hora = F-Fecha (Get-Date); equipo = $env:COMPUTERNAME
    cpu_pct = [math]::Round($cpu, 0); ram_total = F-GB ($os.TotalVisibleMemorySize * 1KB); ram_uso = F-GB (($os.TotalVisibleMemorySize - $os.FreePhysicalMemory) * 1KB)
    ram_pct = [math]::Round(100 - ($os.FreePhysicalMemory / $os.TotalVisibleMemorySize * 100), 0)
    uptime = ('{0}d {1}h {2}m' -f $up.Days, $up.Hours, $up.Minutes); procesos = (Get-Process).Count
    top = $top; discos = $discos; red = $net
    defender_rt = $mp.RealTimeProtectionEnabled; firmas_dias = $mp.AntivirusSignatureAge
    sesiones = @(query user 2>$null | Select-Object -Skip 1 | ForEach-Object { ($_ -replace '\s{2,}', ' ').Trim() })
  }
}

# ---------- HTML ----------

# Ojo: no llamar a esta función "H": en PowerShell "h" es alias de Get-History y gana a las funciones.
function Esc($s) { if ($s -eq $null) { return '' } return [System.Net.WebUtility]::HtmlEncode("$s") }

function Tabla($filas, $cols) {
  if (-not $filas -or @($filas).Count -eq 0) { return '<p class="vacio">Sin datos.</p>' }
  $sb = New-Object Text.StringBuilder
  [void]$sb.Append('<div class="tw"><table><thead><tr>')
  foreach ($c in $cols) { [void]$sb.Append("<th>$(Esc ($c -replace '_',' '))</th>") }
  [void]$sb.Append('</tr></thead><tbody>')
  foreach ($f in @($filas)) {
    $cls = ''
    if ($f.sospechoso -or $f.sospechosa -or $f.fuera_tienda) { $cls = ' class="mal"' }
    [void]$sb.Append("<tr$cls>")
    foreach ($c in $cols) {
      $v = $f.$c
      if ($v -is [bool]) { $v = $(if ($v) { 'sí' } else { 'no' }) }
      elseif ($v -is [array]) { $v = $v -join ', ' }
      [void]$sb.Append("<td>$(Esc $v)</td>")
    }
    [void]$sb.Append('</tr>')
  }
  [void]$sb.Append('</tbody></table></div>')
  return $sb.ToString()
}

function KV($obj, $claves) {
  $sb = New-Object Text.StringBuilder
  [void]$sb.Append('<dl class="kv">')
  foreach ($k in $claves) { $v = $obj.$k; if ($v -is [bool]) { $v = $(if ($v) { 'sí' } else { 'no' }) } elseif ($v -is [array]) { $v = $v -join ', ' }; [void]$sb.Append("<dt>$(Esc ($k -replace '_',' '))</dt><dd>$(Esc $v)</dd>") }
  [void]$sb.Append('</dl>'); return $sb.ToString()
}

function Get-AuroraCss {
@'
:root{color-scheme:dark;--bg:#03090f;--bg2:#071320;--card:#0a1826;--ink:#eefcf8;--muted:#8fb3b6;--line:rgba(44,245,200,.22);--mint:#2cf5c8;--blue:#6a7bff;--pink:#ff4fa3;--soft:#a9fff0;--amber:#ffc46a;--sans:"Space Grotesk",system-ui,-apple-system,"Segoe UI",sans-serif;--mono:"JetBrains Mono",ui-monospace,Consolas,monospace}
*{box-sizing:border-box}html{-webkit-text-size-adjust:100%}
body{margin:0;background:var(--bg);color:var(--ink);font-family:var(--sans);line-height:1.5;font-size:15px;background-image:radial-gradient(900px 500px at 10% -10%,rgba(106,123,255,.18),transparent 60%),radial-gradient(800px 500px at 100% 0%,rgba(44,245,200,.12),transparent 60%)}
a{color:var(--mint)}
.wrap{max-width:1180px;margin:0 auto;padding:24px 16px 64px}
header{display:flex;align-items:center;gap:16px;flex-wrap:wrap;padding:8px 0 20px;border-bottom:1px solid var(--line)}
header svg,header img{width:52px;height:36px}
header h1{font-size:22px;margin:0;font-weight:600;letter-spacing:.2px}
header h1 span{color:var(--mint)}
header .sub{color:var(--muted);font-family:var(--mono);font-size:12.5px}
.chip{display:inline-block;border:1px solid var(--line);border-radius:999px;padding:2px 10px;font-family:var(--mono);font-size:12px;color:var(--soft);background:rgba(44,245,200,.06)}
.score{margin-left:auto;display:flex;align-items:center;gap:14px}
.ring{width:84px;height:84px;border-radius:50%;display:grid;place-items:center;font-family:var(--mono);font-size:24px;font-weight:600;background:conic-gradient(var(--tone) calc(var(--p)*1%),rgba(255,255,255,.06) 0);position:relative}
.ring::after{content:"";position:absolute;inset:7px;border-radius:50%;background:var(--bg2)}
.ring b{position:relative;z-index:1}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:14px;margin-top:18px}
.card{background:linear-gradient(180deg,rgba(255,255,255,.03),rgba(255,255,255,0)),var(--card);border:1px solid var(--line);border-radius:14px;padding:16px 16px 12px;min-width:0}
.card.full{grid-column:1/-1}
.card h2{margin:0 0 10px;font-size:15px;font-weight:600;color:var(--soft);display:flex;align-items:center;gap:8px}
.card h2 small{color:var(--muted);font-weight:400;font-family:var(--mono);font-size:11.5px;margin-left:auto}
.kv{display:grid;grid-template-columns:minmax(120px,38%) 1fr;gap:4px 12px;margin:0;font-size:13.5px}
.kv dt{color:var(--muted)}.kv dd{margin:0;font-family:var(--mono);font-size:12.5px;word-break:break-word}
.tw{overflow:auto;max-height:420px;border:1px solid rgba(255,255,255,.06);border-radius:10px}
table{border-collapse:collapse;width:100%;font-size:12.5px;font-family:var(--mono)}
th{position:sticky;top:0;background:#0d2033;text-align:left;padding:7px 9px;color:var(--soft);font-weight:500;white-space:nowrap}
td{padding:6px 9px;border-top:1px solid rgba(255,255,255,.05);vertical-align:top;word-break:break-word;max-width:420px}
tr.mal td{background:rgba(255,79,163,.08)}
.vacio{color:var(--muted);font-size:13px;margin:4px 0}
.hall{display:grid;gap:10px}
.h{display:grid;grid-template-columns:auto 1fr;gap:12px;align-items:start;padding:12px 14px;border-radius:12px;border:1px solid var(--line);background:rgba(255,255,255,.02)}
.h .lv{font-family:var(--mono);font-size:11px;letter-spacing:.6px;text-transform:uppercase;padding:3px 9px;border-radius:999px;margin-top:2px;white-space:nowrap}
.h.critico{border-color:rgba(255,79,163,.5)}.h.critico .lv{background:rgba(255,79,163,.18);color:var(--pink)}
.h.aviso{border-color:rgba(255,196,106,.45)}.h.aviso .lv{background:rgba(255,196,106,.16);color:var(--amber)}
.h.info .lv{background:rgba(106,123,255,.18);color:#b9c1ff}
.h.ok .lv{background:rgba(44,245,200,.14);color:var(--mint)}
.h b{font-weight:600}.h p{margin:3px 0 0;color:var(--muted);font-size:13.5px}.h p.acc{color:var(--ink)}
.h p.acc::before{content:"→ ";color:var(--mint)}
.bar{height:8px;border-radius:999px;background:rgba(255,255,255,.07);overflow:hidden;margin:4px 0 8px}
.bar i{display:block;height:100%;background:linear-gradient(90deg,var(--mint),var(--blue));border-radius:999px}
.bar.hot i{background:linear-gradient(90deg,var(--amber),var(--pink))}
footer{margin-top:28px;color:var(--muted);font-size:12px;font-family:var(--mono);border-top:1px solid var(--line);padding-top:14px;display:flex;flex-wrap:wrap;gap:10px 20px}
details summary{cursor:pointer;color:var(--soft);font-size:13px;margin:6px 0}
pre{font-family:var(--mono);font-size:11.5px;color:var(--muted);white-space:pre-wrap;max-height:300px;overflow:auto}
@media print{body{background:#fff;color:#111}.card{border-color:#ccc;background:#fff}.tw{max-height:none}th{background:#eee;color:#111}}
'@
}

function Get-AuroraLogoSvg {
  $p = Join-Path $script:RecolectorDir 'aurora-isotipo.svg'
  if (Test-Path $p) { return (Get-Content $p -Raw -Encoding UTF8) }
  return '<svg viewBox="0 0 52 36" xmlns="http://www.w3.org/2000/svg"><path d="M4 32 26 4l22 28H36L26 16 16 32z" fill="#2cf5c8"/></svg>'
}

function ConvertTo-AuroraHtml($d) {
  $s = $d.sistema.datos; $hal = $d.hallazgos; $sec = $d.seguridad.datos; $dis = $d.discos.datos
  $tone = if ($hal.puntaje -ge 80) { 'var(--mint)' } elseif ($hal.puntaje -ge 50) { 'var(--amber)' } else { 'var(--pink)' }
  $sb = New-Object Text.StringBuilder
  [void]$sb.Append("<!doctype html><html lang=`"es`"><head><meta charset=`"utf-8`"><meta name=`"viewport`" content=`"width=device-width,initial-scale=1`"><title>Aurora Diagnóstico · $(Esc $s.equipo)</title><link rel=`"preconnect`" href=`"https://fonts.googleapis.com`"><link href=`"https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap`" rel=`"stylesheet`"><style>$(Get-AuroraCss)</style></head><body><div class=`"wrap`">")
  [void]$sb.Append("<header>$(Get-AuroraLogoSvg)<div><h1>Aurora <span>Diagnóstico</span></h1><div class=`"sub`">$(Esc $s.equipo) · $(Esc $s.usuario) · $(Esc $d.meta.generado) · v$(Esc $d.meta.version)</div></div><div class=`"score`"><div><div style=`"color:var(--muted);font-size:12px`">Estado general</div><div><span class=`"chip`">$($hal.criticos) críticos</span> <span class=`"chip`">$($hal.avisos) avisos</span></div></div><div class=`"ring`" style=`"--p:$($hal.puntaje);--tone:$tone`"><b>$($hal.puntaje)</b></div></div></header>")

  # hallazgos
  [void]$sb.Append('<div class="grid"><section class="card full"><h2>Hallazgos <small>ordenados por gravedad</small></h2><div class="hall">')
  foreach ($h in $hal.lista) {
    [void]$sb.Append("<div class=`"h $($h.nivel)`"><span class=`"lv`">$($h.nivel)</span><div><b>$(Esc $h.titulo)</b>")
    if ($h.detalle) { [void]$sb.Append("<p>$(Esc $h.detalle)</p>") }
    if ($h.accion) { [void]$sb.Append("<p class=`"acc`">$(Esc $h.accion)</p>") }
    [void]$sb.Append('</div></div>')
  }
  [void]$sb.Append('</div></section>')

  # sistema
  [void]$sb.Append("<section class=`"card`"><h2>Sistema</h2>$(KV $s 'so','version','fabricante','placa','bios','cpu','nucleos','gpu','ultimo_arranque','uptime','bateria','es_admin')")
  $ramcls = if ($s.ram_uso_pct -ge 90) { 'bar hot' } else { 'bar' }
  [void]$sb.Append("<div style=`"margin-top:10px;font-size:13px;color:var(--muted)`">RAM $($s.ram_total_gb - $s.ram_libre_gb) / $($s.ram_total_gb) GB ($($s.ram_uso_pct)%)</div><div class=`"$ramcls`"><i style=`"width:$($s.ram_uso_pct)%`"></i></div></section>")

  # discos
  [void]$sb.Append('<section class="card"><h2>Discos</h2>')
  foreach ($v in $dis.volumenes) { $u = 100 - $v.libre_pct; $c = if ($v.libre_pct -lt 10) { 'bar hot' } else { 'bar' }; [void]$sb.Append("<div style=`"font-size:13px`"><b>$(Esc $v.unidad)</b> $(Esc $v.etiqueta) · $($v.libre_gb) GB libres de $($v.total_gb) GB</div><div class=`"$c`"><i style=`"width:$u%`"></i></div>") }
  [void]$sb.Append((Tabla $dis.fisicos 'nombre', 'tipo', 'bus', 'salud', 'tam_gb'))
  if ($dis.fiabilidad.Count) { [void]$sb.Append("<details><summary>Fiabilidad (SMART)</summary>$(Tabla $dis.fiabilidad 'id','temp_c','horas','errores_lectura','desgaste')</details>") }
  [void]$sb.Append('</section>')

  # rendimiento
  $rd = $d.rendimiento.datos
  if ($rd) {
    $ds = if ($rd.disco_sistema) { "$($rd.disco_sistema.nombre) ($($rd.disco_sistema.tipo), $($rd.disco_sistema.bus))" } else { 'no determinado' }
    $dcls = if ($rd.disco_ocupado_pct -ge 80) { 'bar hot' } else { 'bar' }
    [void]$sb.Append("<section class=`"card`"><h2>Rendimiento <small>causas de PC lenta</small></h2><dl class=`"kv`"><dt>disco del sistema</dt><dd>$(Esc $ds)</dd><dt>plan de energía</dt><dd>$(Esc $rd.plan_energia)</dd><dt>RAM instalada</dt><dd>$($rd.ram_total_gb) GB</dd><dt>paginación</dt><dd>$($rd.pagefile_uso_mb) MB de $($rd.pagefile_mb) MB</dd><dt>Windows Search</dt><dd>$(Esc $rd.windows_search)</dd><dt>SysMain</dt><dd>$(Esc $rd.sysmain)</dd><dt>TRIM</dt><dd>$(Esc $rd.trim_activo)</dd></dl><div style=`"margin-top:10px;font-size:13px;color:var(--muted)`">Actividad del disco ahora: $($rd.disco_ocupado_pct)% · cola $($rd.disco_cola)</div><div class=`"$dcls`"><i style=`"width:$($rd.disco_ocupado_pct)%`"></i></div><details><summary>Apps que arrancan con Windows ($($rd.arranque_total))</summary><pre>$(Esc ($rd.arranque_habilitadas -join "`n"))</pre></details></section>")
  }

  # seguridad
  if ($sec) {
    [void]$sb.Append("<section class=`"card`"><h2>Defender y firewall</h2>$(KV $sec.defender 'antivirus','tiempo_real','firmas','ultimo_rapido','ultimo_completo','tamper')$(Tabla $sec.firewall 'perfil','activo','entrada_defecto')$(Tabla $sec.redes 'red','categoria','adaptador')<div style=`"margin-top:8px;font-size:13px`">RDP habilitado: <b>$(if ($sec.rdp_habilitado) { 'sí' } else { 'no' })</b></div></section>")
    [void]$sb.Append("<section class=`"card full`"><h2>Inicios de sesión fallidos y bloqueos <small>7 días · requiere administrador</small></h2>$(if ($sec.seguridad_error) { "<p class='vacio'>$(Esc $sec.seguridad_error)</p>" })$(Tabla $sec.logons_fallidos_7d 'cuenta','tipo_logon','proceso','ip','veces','primero','ultimo','subestado')<details><summary>Bloqueos de cuenta ($($sec.bloqueos_7d.Count))</summary>$(Tabla $sec.bloqueos_7d 'hora','cuenta','equipo_llamador')</details><details><summary>Política de bloqueo</summary>$(KV $sec.politica_bloqueo @($sec.politica_bloqueo.Keys))</details></section>")
    [void]$sb.Append("<section class=`"card`"><h2>Puertos en escucha <small>$($sec.puertos_escucha.Count)</small></h2>$(Tabla $sec.puertos_escucha 'puerto','direccion','proceso','pid')</section>")
  }

  # arranques
  $arr = $d.arranques.datos
  [void]$sb.Append("<section class=`"card`"><h2>Arranques y apagados <small>7 días · $($arr.apagados_inesperados_7d) inesperados</small></h2>$(Tabla $arr.eventos 'hora','tipo','detalle')</section>")

  # navegadores
  $nav = $d.navegadores.datos
  [void]$sb.Append('<section class="card full"><h2>Navegadores</h2>')
  foreach ($p in $nav.perfiles) {
    [void]$sb.Append("<details><summary><b>$(Esc $p.navegador)</b> · $(Esc $p.nombre) <span class=`"chip`">$(Esc $p.cuenta)</span> · última salida: $(Esc $p.salida) · Hello al rellenar: $(if ($p.hello_al_rellenar) { '<b style=''color:var(--amber)''>sí</b>' } else { 'no' }) · $($p.extensiones.Count) extensiones$(if ($p.extensiones_fuera_tienda) { " <b style='color:var(--pink)'>($($p.extensiones_fuera_tienda) fuera de tienda)</b>" })</summary>$(Tabla $p.extensiones 'nombre','version','tienda','instalada','id')</details>")
  }
  [void]$sb.Append('</section>')

  # procesos
  $pr = $d.procesos.datos
  [void]$sb.Append("<section class=`"card`"><h2>Procesos · más CPU <small>$($pr.total) en total</small></h2>$(Tabla $pr.top_cpu 'nombre','pid','cpu_pct','ram_mb')</section><section class=`"card`"><h2>Procesos · más RAM</h2>$(Tabla $pr.top_ram 'nombre','pid','ram_mb','cpu_pct')</section>")
  [void]$sb.Append("<section class=`"card full`"><h2>Procesos sin firma o en rutas inusuales <small>$($pr.sospechosos.Count)</small></h2>$(Tabla $pr.sospechosos 'nombre','pid','firma','firmante','ruta')</section>")

  # persistencia
  $per = $d.persistencia.datos
  [void]$sb.Append("<section class=`"card full`"><h2>Arranque automático</h2>$(Tabla $per.run 'clave','nombre','comando')<details><summary>Carpetas de inicio ($($per.carpeta_inicio.Count))</summary>$(Tabla $per.carpeta_inicio 'archivo','carpeta','modificado')</details><details><summary>Tareas programadas de terceros ($($per.tareas.Count))</summary>$(Tabla $per.tareas 'tarea','estado','ultima','accion')</details><details><summary>Servicios de terceros ($($per.servicios_terceros.Count))</summary>$(Tabla $per.servicios_terceros 'servicio','nombre','estado','inicio','cuenta','ruta')</details><details><summary>Programas instalados últimos 30 días ($($per.programas_30d.Count))</summary>$(Tabla $per.programas_30d 'programa','version','editor','fecha')</details></section>")

  # red
  $red = $d.red.datos
  [void]$sb.Append("<section class=`"card`"><h2>Red</h2>$(Tabla $red.adaptadores 'adaptador','ipv4','puerta','dns','estado')<div style=`"font-size:13px;margin-top:8px`">Puerta de enlace responde: <b>$(Esc $red.puerta_responde)</b> · Internet: <b>$(Esc $red.internet)</b></div>$(if ($red.wifi.Count) { "<pre>$(Esc ($red.wifi -join "`n"))</pre>" })</section>")
  [void]$sb.Append("<section class=`"card`"><h2>Conexiones salientes por proceso</h2>$(Tabla $red.conexiones_salientes 'proceso','pid','conexiones','destinos')</section>")

  # crashes
  $cr = $d.crashes.datos
  [void]$sb.Append("<section class=`"card`"><h2>Fallos de aplicaciones <small>7 días</small></h2>$(Tabla $cr.apps_7d 'aplicacion','veces','ultimo','modulo')<details><summary>Informes de errores de Windows</summary>$(Tabla $cr.wer_7d 'evento','veces')</details><details><summary>Volcados de memoria</summary>$(Tabla $cr.volcados 'archivo','fecha','mb')</details></section>")
  [void]$sb.Append("<section class=`"card`"><h2>Errores del sistema <small>48 h</small></h2>$(Tabla $cr.sistema_errores_48h 'origen','id','veces','ultimo','mensaje')</section>")

  # cuentas y actualizaciones
  $cu = $d.cuentas.datos; $ac = $d.actualizaciones.datos
  [void]$sb.Append("<section class=`"card`"><h2>Cuentas locales</h2>$(Tabla $cu.usuarios 'nombre','activa','origen','ultimo_logon','clave_requerida')<div style=`"font-size:13px;margin-top:8px;color:var(--muted)`">Administradores: $(Esc ($cu.administradores -join ', '))</div></section>")
  if ($ac) { [void]$sb.Append("<section class=`"card`"><h2>Actualizaciones</h2><div style=`"font-size:13px`">Reinicio pendiente: <b>$(if ($ac.reinicio_pendiente) { 'sí' } else { 'no' })</b> · Chrome $(Esc $ac.chrome_version)</div>$(Tabla $ac.historial 'fecha','resultado','titulo')<details><summary>Hotfix</summary>$(Tabla $ac.hotfix 'kb','tipo','fecha')</details></section>") }

  $tiempos = ($d.Keys | Where-Object { $d[$_] -is [System.Collections.Specialized.OrderedDictionary] -and $d[$_].Contains('ms') } | ForEach-Object { "$_ $($d[$_].ms) ms" }) -join ' · '
  [void]$sb.Append("</div><footer><span>Aurora Hub Perú · aurorahubperu.com</span><span>Generado sin enviar datos a ningún servidor.</span><span>$(Esc $tiempos)</span></footer></div></body></html>")
  return $sb.ToString()
}

function Export-AuroraInforme {
  [CmdletBinding()] param([Parameter(Mandatory)]$Datos, [Parameter(Mandatory)][string]$Carpeta, [string]$Prefijo)
  New-Item -ItemType Directory -Force -Path $Carpeta | Out-Null
  if (-not $Prefijo) { $Prefijo = "$($Datos.meta.equipo)_$((Get-Date).ToString('yyyy-MM-dd_HHmm'))" }
  $html = Join-Path $Carpeta "$Prefijo.html"; $json = Join-Path $Carpeta "$Prefijo.json"
  $utf8 = New-Object System.Text.UTF8Encoding($true)
  [IO.File]::WriteAllText($html, (ConvertTo-AuroraHtml $Datos), $utf8)
  [IO.File]::WriteAllText($json, ($Datos | ConvertTo-Json -Depth 8 -Compress), $utf8)
  return [ordered]@{ html = $html; json = $json }
}

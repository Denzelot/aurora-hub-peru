﻿# Aurora Diagnóstico · versión para clientes
# Pide la clave, revisa el equipo, guarda una copia local y envía el informe a Aurora Hub Perú.
[CmdletBinding()]
param([string]$Clave, [string]$Api = 'https://api.aurorahubperu.com/api/diagnostico', [switch]$NoEnviar, [switch]$SinSonido)
$ErrorActionPreference = 'Continue'
$Dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$rec = Join-Path $Dir 'Recolector.ps1'
if (-not (Test-Path $rec)) { $rec = Join-Path (Split-Path -Parent $Dir) 'comun\Recolector.ps1' }   # en la carpeta de desarrollo
if (-not (Test-Path $rec)) { Write-Host '  Falta Recolector.ps1. Extrae el ZIP completo antes de ejecutar.' -ForegroundColor Red; Read-Host '  Pulsa Enter para salir' | Out-Null; exit 1 }
. $rec
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
try { $host.UI.RawUI.WindowTitle = 'Aurora Diagnóstico · Aurora Hub Perú'; $host.UI.RawUI.BackgroundColor = 'Black'; Clear-Host } catch {}

function Linea($t, $c = 'Gray') { Write-Host "  $t" -ForegroundColor $c }
# Sonidos (WAV generados con numpy en servicio\generar_sonidos.py). Nunca detienen el programa si fallan.
$script:sonidos = Join-Path $Dir 'sonidos'
function Son($nombre, [switch]$Esperar) {
  if ($SinSonido) { return }
  $w = Join-Path $script:sonidos "$nombre.wav"
  if (-not (Test-Path $w)) { return }
  try { $p = New-Object System.Media.SoundPlayer $w; if ($Esperar) { $p.PlaySync() } else { $p.Play() } } catch {}
}
Son 'inicio'
Write-Host ''
Write-Host '   █████╗ ██╗   ██╗██████╗  ██████╗ ██████╗  █████╗ ' -ForegroundColor Cyan
Write-Host '  ██╔══██╗██║   ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗' -ForegroundColor Cyan
Write-Host '  ███████║██║   ██║██████╔╝██║   ██║██████╔╝███████║' -ForegroundColor Cyan
Write-Host '  ██╔══██║██║   ██║██╔══██╗██║   ██║██╔══██╗██╔══██║' -ForegroundColor Blue
Write-Host '  ██║  ██║╚██████╔╝██║  ██║╚██████╔╝██║  ██║██║  ██║' -ForegroundColor Magenta
Write-Host '  ╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝' -ForegroundColor Magenta
Write-Host ''
Linea 'DIAGNÓSTICO DE PC · Aurora Hub Perú · aurorahubperu.com' 'White'
Linea 'Este programa revisa el estado de tu equipo y envía el informe a Aurora Hub.' 'DarkGray'
Linea 'No toca tus archivos, no cambia nada y no recoge contraseñas.' 'DarkGray'
Write-Host ''
if (-not (Test-EsAdmin)) { Linea 'Aviso: se abrió sin permisos de administrador; el informe saldrá incompleto.' 'Yellow'; Linea 'Cierra esta ventana y vuelve a abrir el programa con clic derecho → Ejecutar como administrador.' 'Yellow'; Write-Host '' }

while ($Clave -notmatch '^AUR-[A-Z2-9]{4}-[A-Z2-9]{4}$') {
  if ($Clave) { Linea 'Esa clave no tiene el formato correcto (ejemplo: AUR-7K3M-PX2Q).' 'Yellow' }
  $Clave = (Read-Host '  Escribe la clave que te dio Aurora Hub').Trim().ToUpper() -replace '\s', ''
  if ($Clave -match '^[A-Z2-9]{4}[- ]?[A-Z2-9]{4}$') { $Clave = 'AUR-' + ($Clave -replace '[- ]', '').Insert(4, '-') }
}
Write-Host ''
Linea 'Revisando el equipo. Tarda entre 1 y 3 minutos; no cierres esta ventana.' 'White'
Write-Host ''
$total = 12; $script:i = 0
Set-AuroraProgreso { param($nombre, $ms, $err) $script:i++; $pct = [int](100 * $script:i / $total); Write-Progress -Activity 'Aurora Diagnóstico' -Status "$nombre ($pct%)" -PercentComplete $pct; Linea ("[{0,2}/{1}] {2}" -f $script:i, $total, $nombre) 'DarkCyan'; Son 'paso' }
$datos = Get-AuroraDiagnostico
Write-Progress -Activity 'Aurora Diagnóstico' -Completed
$datos.meta.clave = $Clave
$copia = Export-AuroraInforme -Datos $datos -Carpeta (Join-Path $Dir 'informe')
$h = $datos.hallazgos
Write-Host ''
Linea ("Revisión terminada. Puntaje {0}/100." -f $h.puntaje) 'White'
Write-Host ''

if ($NoEnviar) { Son 'listo' -Esperar; Linea "Copia guardada en: $($copia.html)" 'Cyan'; exit 0 }

Linea 'Enviando el informe a Aurora Hub…' 'White'
$cuerpo = [ordered]@{
  clave = $Clave; equipo = $datos.meta.equipo; usuario = $datos.sistema.datos.usuario
  puntaje = $h.puntaje; criticos = $h.criticos; avisos = $h.avisos
  hallazgos = @($h.lista | Where-Object { $_.nivel -in 'critico', 'aviso' } | ForEach-Object { "[$($_.nivel)] $($_.titulo)" })
  html = [IO.File]::ReadAllText($copia.html, [Text.Encoding]::UTF8)
  json = [IO.File]::ReadAllText($copia.json, [Text.Encoding]::UTF8)
}
$ok = $false; $msg = ''
for ($intento = 1; $intento -le 3 -and -not $ok; $intento++) {
  try {
    $bytes = [Text.Encoding]::UTF8.GetBytes(($cuerpo | ConvertTo-Json -Depth 4 -Compress))
    $r = Invoke-RestMethod -Method Post -Uri $Api -ContentType 'application/json; charset=utf-8' -Body $bytes -TimeoutSec 60
    if ($r.ok) { $ok = $true } else { $msg = "$($r.error)" }
  } catch {
    $msg = $_.Exception.Message
    try { $sr = New-Object IO.StreamReader($_.Exception.Response.GetResponseStream()); $j = $sr.ReadToEnd() | ConvertFrom-Json; if ($j.error) { $msg = $j.error } } catch {}
    if ($msg -match 'Clave no válida') { break }
    Start-Sleep -Seconds (3 * $intento)
  }
}
Write-Host ''
if ($ok) {
  Son 'listo'
  Linea '✔ Informe enviado. Aurora Hub te contactará por WhatsApp con el resultado.' 'Green'
  Linea "  Tu clave: $Clave" 'DarkGray'
} else {
  Son 'error'
  Linea "✖ No se pudo enviar el informe ($msg)." 'Red'
  Linea 'No pasa nada: quedó guardado en tu equipo. Envía este archivo por WhatsApp a Aurora Hub:' 'Yellow'
  Linea "  $($copia.html)" 'White'
  try { Start-Process explorer.exe "/select,`"$($copia.html)`"" } catch {}
}
Write-Host ''
Linea 'Ya puedes cerrar esta ventana.' 'DarkGray'
Read-Host '  Pulsa Enter para salir' | Out-Null

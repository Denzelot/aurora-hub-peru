@echo off
:: Aurora Diagnostico - Aurora Hub Peru. Doble clic y sigue las indicaciones.
setlocal
net session >nul 2>&1
if %errorlevel% neq 0 (
  echo Pidiendo permisos de administrador para revisar el equipo...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
title Aurora Diagnostico
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0cliente.ps1" %*
if %errorlevel% neq 0 (
  echo.
  echo Hubo un problema. Toma una captura de esta ventana y envíala por WhatsApp a Aurora Hub.
  pause
)
endlocal
